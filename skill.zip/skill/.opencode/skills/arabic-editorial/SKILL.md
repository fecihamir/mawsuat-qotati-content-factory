---
name: arabic-editorial
description: Shared Mawsu'at Qotati rules for Arabic editorial voice, cat taxonomy, evidence boundaries, and website-compatible content.
---

# Mawsu'at Qotati Editorial Rules

Use this skill for every content-factory research handoff, brief, article, and QA task.

## Voice

- Write clear Modern Standard Arabic that a broad Arab audience can read comfortably.
- Lead with the answer, then explain context and practical meaning.
- Prefer specific, calm wording over hype, filler, or translation-like phrasing.
- Keep the voice warm and observant without pretending to be a veterinarian or a named expert.
- Vary sentence length naturally and remove repeated conclusions.

## Evidence Boundary

`SOURCE != TRUTH`.

An article, web page, video, transcript, blog, or creator statement is source material. Important claims need source IDs, evidence, source agreement or conflict, a decision status, a reason, and writer guidance. Only `APPROVED` and `QUALIFIED` decisions may be written as article facts. A `QUALIFIED` decision must retain its qualification. `REJECTED` and `NEEDS_RESEARCH` decisions are excluded.

## Taxonomy

Use only these top-level category slugs: `breeds`, `food`, `behavior`, `care`, `kittens`, `questions`, and `names`. Do not add a medical category. Avoid veterinary diagnosis and the V1 mating, pregnancy, and birth category. Health-adjacent material must remain cautious educational guidance.

## Article Shape

The local structured article should remain close to the inspected website's `Article` interface: Arabic title and excerpt, category and slug, author metadata, introduction paragraphs, a table of contents, typed sections and blocks, conclusion, FAQs, related category slugs, and SEO overrides. Keep factual claim IDs in a separate claim map rather than inserting unsupported citations into prose.

## SEO

Use the actual search question naturally in the title, introduction, headings, and metadata where helpful. Never keyword stuff, create misleading clickbait, or introduce facts not present in the evidence packet.
