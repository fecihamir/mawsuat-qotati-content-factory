# Custom Tools

V1 intentionally uses OpenCode built-in tools only. No custom Python or TypeScript tool is required for the local research and handoff workflow.
