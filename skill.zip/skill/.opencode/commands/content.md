---
description: Run the Arabic content pipeline and stop at human approval
agent: coordinator
model: opencode/mimo-v2.5-free
---

Start one Mawsu'at Qotati content job for the single input `$ARGUMENTS`.

The input must be exactly one of:

- a non-empty Arabic or English keyword
- a public HTTPS article URL
- a public HTTPS YouTube URL

Pass the input to the `coordinator`. It must create a job workspace and run, in order: Researcher, Fact Checker, Content Strategist, Writer / Editor, and SEO / QA. Require a traceable artifact at every stage, report progress after each stage, and stop at `PENDING_APPROVAL`.

Do not approve, publish, deploy, push production content, modify `D:\mycatkitty`, add Cloudflare, or create any agent beyond the six project agents. A URL is starting material, not truth.
