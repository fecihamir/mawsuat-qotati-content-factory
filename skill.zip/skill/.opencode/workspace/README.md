# Content Job Workspace

The Coordinator creates one directory per run under `jobs/`:

```text
jobs/<job-id>/
  input/request.json
  input/request.md
  research/research.md
  research/sources.json
  evidence/evidence.json
  evidence/report.md
  brief/brief.json
  brief/brief.md
  draft/article.json
  draft/article.md
  edited/article.json
  edited/article.md
  edited/claim-map.json
  edited/editor-notes.md
  seo/metadata.json
  seo/claim-audit.json
  seo/report.md
  approval/status.json
  approval/review.md
  published/structured-output.json
```

`published/structured-output.json` must not exist while the approval state is `PENDING_APPROVAL`, `CHANGES_REQUESTED`, or `REJECTED`. It is a local, approved handoff package, not an external publication.

## Evidence Contract

Each important claim in `evidence/evidence.json` must retain:

- claim ID and claim text
- source IDs and URLs
- evidence summary
- agreement or conflict
- status: `APPROVED`, `QUALIFIED`, `REJECTED`, or `NEEDS_RESEARCH`
- reason
- writer guidance

The article claim map may reference only `APPROVED` or `QUALIFIED` evidence. SEO/QA blocks the job when a claim is rejected, unresolved, or untraceable.

## Website Mapping

`edited/article.json` follows the inspected website's `Article` shape closely enough for a later adapter: `categorySlug`, `categoryNameAr`, `subcategorySlug`, `titleAr`, `excerptAr`, `coverImageUrl`, `coverImageAltAr`, author metadata, dates, `readingTimeMinutes`, `intent`, `tagsAr`, `introductionParagraphsAr`, `tableOfContents`, typed `sections`, `conclusionAr`, `faqs`, related links, and `seo`.

Do not copy this workspace into the website project. Do not add external integrations in V1.
